
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import {
  ArrowLeft,
  CalendarDays,
  FileText,
  ChevronDown,
  ChevronUp,
  Plus,
  RefreshCw,
  ClipboardList,
  AlertCircle,
} from "lucide-react";

import { getMyConsultations } from "../../../services/consultationService.js";

// Format consultation date
function formatDate(date) {
  return new Date(date).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

// Safely extract a short report description
function getReportSummary(report) {
  if (typeof report === "string") {
    return report.slice(0, 180);
  }

  if (!report || typeof report !== "object") {
    return "Your AI-generated consultation report is ready.";
  }

  const possibleFields = [
    "summary",
    "overview",
    "chiefComplaint",
    "primaryConcern",
    "presentingComplaint",
    "description",
  ];

  for (const field of possibleFields) {
    if (typeof report[field] === "string" && report[field].trim()) {
      return report[field].slice(0, 180);
    }
  }

  return "Your consultation report contains your submitted symptoms, medical history and AI-generated clinical summary.";
}

// Format report field names
function formatLabel(label) {
  return label
    .replace(/([A-Z])/g, " $1")
    .replace(/[_-]/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

// Display complete report
function ReportDetails({ report }) {
  if (typeof report === "string") {
    return (
      <div className="whitespace-pre-wrap text-sm leading-7 text-gray-700">
        {report}
      </div>
    );
  }

  if (!report || typeof report !== "object") {
    return <p className="text-sm text-gray-500">Report details unavailable.</p>;
  }

  return (
    <div className="space-y-4">
      {Object.entries(report).map(([key, value]) => {
        if (value === null || value === undefined || value === "") {
          return null;
        }

        const displayValue =
          typeof value === "object"
            ? JSON.stringify(value, null, 2)
            : String(value);

        return (
          <div
            key={key}
            className="rounded-xl border border-[#E7E7DF] bg-white p-4"
          >
            <h4 className="mb-2 text-sm font-semibold text-[#315F53]">
              {formatLabel(key)}
            </h4>

            <p className="whitespace-pre-wrap break-words text-sm leading-6 text-gray-600">
              {displayValue}
            </p>
          </div>
        );
      })}
    </div>
  );
}

export default function MyConsultations() {
  const [consultations, setConsultations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [expandedId, setExpandedId] = useState(null);

  async function fetchConsultations() {
    try {
      setLoading(true);
      setError("");

      const data = await getMyConsultations();

      setConsultations(data);
    } catch (err) {
      console.error("Consultations loading error:", err);
      setError(err.message || "Unable to load consultations.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchConsultations();
  }, []);

  return (
    <div className="mx-auto max-w-5xl">

      {/* Back navigation */}
      <Link
        to="/patient/dashboard"
        className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-[#47796E] hover:underline"
      >
        <ArrowLeft size={17} />
        Back to Dashboard
      </Link>

      {/* Page heading */}
      <div className="mb-7 flex flex-wrap items-center justify-between gap-4">

        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#E0EEE7] text-[#47796E]">
              <ClipboardList size={25} />
            </div>

            <div>
              <h1 className="text-2xl font-bold text-[#214D43]">
                My Consultations
              </h1>

              <p className="mt-1 text-sm text-gray-500">
                View your consultation history and AI-generated reports.
              </p>
            </div>
          </div>
        </div>

        <Link
          to="/patient/consultation/new"
          className="inline-flex items-center gap-2 rounded-xl bg-[#326F61] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#285C50]"
        >
          <Plus size={18} />
          New Consultation
        </Link>

      </div>

      {/* Consultation count */}
      {!loading && !error && (
        <div className="mb-6 rounded-xl border border-[#DCE7DF] bg-[#F4F8F6] p-4">
          <p className="text-sm text-[#718096]">
            Total consultations
          </p>

          <p className="mt-1 text-2xl font-bold text-[#214D43]">
            {consultations.length}
          </p>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="rounded-2xl border border-[#E7E7DF] bg-white px-6 py-16 text-center">
          <RefreshCw
            size={30}
            className="mx-auto animate-spin text-[#47796E]"
          />

          <p className="mt-4 text-sm font-medium text-[#315F53]">
            Loading your consultations...
          </p>
        </div>
      )}

      {/* Error */}
      {!loading && error && (
        <div className="rounded-2xl border border-red-200 bg-white p-8 text-center">
          <AlertCircle
            size={35}
            className="mx-auto text-red-500"
          />

          <h3 className="mt-4 font-semibold text-[#214D43]">
            Unable to load consultations
          </h3>

          <p className="mt-2 text-sm text-gray-500">
            {error}
          </p>

          <button
            onClick={fetchConsultations}
            className="mt-5 rounded-lg bg-[#326F61] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#285C50]"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Empty state */}
      {!loading && !error && consultations.length === 0 && (
        <div className="rounded-2xl border border-dashed border-[#CADBD0] bg-white px-6 py-16 text-center">

          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#E0EEE7] text-[#47796E]">
            <FileText size={32} />
          </div>

          <h3 className="mt-5 text-lg font-bold text-[#214D43]">
            No consultations yet
          </h3>

          <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-gray-500">
            Your completed consultations and AI-generated
            medical reports will appear here.
          </p>

          <Link
            to="/patient/consultation/new"
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#326F61] px-6 py-3 text-sm font-semibold text-white hover:bg-[#285C50]"
          >
            <Plus size={18} />
            Start Your First Consultation
          </Link>

        </div>
      )}

      {/* Consultation list */}
      {!loading && !error && consultations.length > 0 && (
        <div className="space-y-5">

          {consultations.map((consultation, index) => {
            const isExpanded = expandedId === consultation._id;

            const report = consultation.finalReport;

            const title =
              typeof report === "object" && report?.title
                ? report.title
                : "Patient Clinical Summary";

            return (
              <div
                key={consultation._id}
                className="overflow-hidden rounded-2xl border border-[#E2E8E2] bg-white shadow-sm"
              >

                {/* Report card */}
                <div className="p-5 sm:p-6">

                  <div className="flex flex-wrap items-start justify-between gap-4">

                    <div className="flex min-w-0 items-start gap-3">

                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#E0EEE7] text-[#47796E]">
                        <FileText size={22} />
                      </div>

                      <div className="min-w-0">
                        <h3 className="font-bold text-[#214D43]">
                          {title}
                        </h3>

                        <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-gray-500">
                          <CalendarDays size={14} />

                          <span>
                            {formatDate(consultation.createdAt)}
                          </span>

                          <span>•</span>

                          <span>
                            Consultation #{consultations.length - index}
                          </span>
                        </div>
                      </div>

                    </div>

                    <span className="rounded-full border border-[#CDE7D7] bg-[#F0FAF3] px-3 py-1.5 text-xs font-semibold text-[#28734A]">
                      Report Generated
                    </span>

                  </div>

                  <p className="mt-4 text-sm leading-6 text-gray-600">
                    {getReportSummary(report)}
                    {getReportSummary(report).length >= 180 ? "..." : ""}
                  </p>

                  <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[#EDF0EA] pt-4">

                    <p className="text-xs text-gray-400">
                      Created on {formatDate(consultation.createdAt)}
                    </p>

                    <button
                      onClick={() =>
                        setExpandedId(
                          isExpanded ? null : consultation._id
                        )
                      }
                      className="inline-flex items-center gap-2 rounded-lg bg-[#E0EEE7] px-4 py-2.5 text-sm font-semibold text-[#315F53] transition hover:bg-[#D3E6DA]"
                    >
                      {isExpanded ? "Hide Report" : "View Full Report"}

                      {isExpanded ? (
                        <ChevronUp size={17} />
                      ) : (
                        <ChevronDown size={17} />
                      )}
                    </button>

                  </div>
                </div>

                {/* Expanded report */}
                {isExpanded && (
                  <div className="border-t border-[#E2E8E2] bg-[#F8FAF6] p-5 sm:p-6">

                    <h4 className="mb-4 font-bold text-[#214D43]">
                      Consultation Report
                    </h4>

                    <ReportDetails report={report} />

                  </div>
                )}

              </div>
            );
          })}

        </div>
      )}

    </div>
  );
}
